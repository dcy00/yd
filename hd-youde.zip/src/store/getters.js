/**
 * Created by liuxiaoya on 2017/12/22 0022.
 */
export const cartNumber = state => state.cartNumber;
