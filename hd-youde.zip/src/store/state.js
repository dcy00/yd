/**
 * Created by liuxiaoya on 2017/12/22 0022.
 */
const state = {
  cartNumber: 0,
}
export default state;
