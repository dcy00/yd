/**
 * Created by liuxiaoya on 2017/12/22 0022.
 */
export const cartNumber = ({commit,state}, cartNum) => {
  commit('SetCartNumber', cartNum);
}
