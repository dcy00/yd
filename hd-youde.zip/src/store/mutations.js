/**
 * Created by liuxiaoya on 2017/12/22 0022.
 */
const mutations = {
  SetCartNumber(state, number){
    state.cartNumber =  number;
  }
}
export default mutations;
