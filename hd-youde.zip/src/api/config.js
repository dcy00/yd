/**
 * Created by liuxiaoya；
 *date 2017/10/11 0011.
 *description
 */
export const URL = "https://www.youde.com";
//export const URL = "/webApi"
